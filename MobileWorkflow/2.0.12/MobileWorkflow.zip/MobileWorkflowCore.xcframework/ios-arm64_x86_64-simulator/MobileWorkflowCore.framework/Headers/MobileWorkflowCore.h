//
//  MobileWorkflowCore.h
//  MobileWorkflowCore
//
//  Created by Jonathan Flintham on 23/09/2020.
//

#import <Foundation/Foundation.h>

//! Project version number for MobileWorkflowCore.
FOUNDATION_EXPORT double MobileWorkflowCoreVersionNumber;

//! Project version string for MobileWorkflowCore.
FOUNDATION_EXPORT const unsigned char MobileWorkflowCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MobileWorkflowCore/PublicHeader.h>

#import <MobileWorkflowCore/MWFileStreamManager.h>
